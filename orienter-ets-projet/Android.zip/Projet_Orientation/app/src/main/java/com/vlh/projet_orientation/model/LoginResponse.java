package com.vlh.projet_orientation.model;

public class LoginResponse {
    private String message;
    private String authToken;

    public String getAuthToken() {
        return authToken;
    }

    public String getMessage() {
        return message;
    }
}
