package com.vlh.projet_orientation.model;

public class User {
    private String email;
    private String password;

    public User(String email, String password) {
        this.email = email;
        this.password = password;
    }

    // (getters et setters facultatifs)
}
